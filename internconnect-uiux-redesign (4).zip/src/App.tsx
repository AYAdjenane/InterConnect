import { useMemo, useState } from "react";
import {
  ArrowUpRight, Bell, Bookmark, Building2, Clock, Eye, FileText, Heart, Mail, Menu, MessageSquare, Phone, Search,
  Shield, Sparkles, Upload, User, Users, X
} from "lucide-react";

type Page = "home" | "jobs" | "dashboard" | "profile" | "login" | "company-dashboard" | "company-profile" | "create-offer" | "candidates";
type Role = "student" | "company";

const studentJobs = [
  { id: 1, role: "Product Design Intern", company: "Sapphire Labs", location: "Algiers", type: "Internship", duration: "6 months", match: 96, saved: true, skills: ["Figma", "UX Research", "Design Systems"], note: "Shape elegant interfaces for a student finance product." },
  { id: 2, role: "Frontend Developer", company: "Royal Blue Studio", location: "Oran", type: "Part-time", duration: "Remote", match: 91, saved: false, skills: ["React", "Tailwind", "TypeScript"], note: "Build refined dashboards for fast-growing startups." },
  { id: 3, role: "Data Analyst Intern", company: "Quicksand AI", location: "Constantine", type: "Internship", duration: "4 months", match: 88, saved: false, skills: ["Python", "SQL", "BI"], note: "Transform recruiting data into actionable student insights." },
  { id: 4, role: "Talent Operations Assistant", company: "Swan Wing Group", location: "Hybrid", type: "PFE", duration: "5 months", match: 84, saved: true, skills: ["Recruiting", "CRM", "Analytics"], note: "Support company partners and improve candidate experience." },
];

const companyOffers = [
  { id: 1, title: "Full Stack Developer", type: "Job", status: "Active", applications: 5, published: "25/01/2026", location: "Bordj Bou Arreridj" },
  { id: 2, title: "Mobile App Developer", type: "Job", status: "Active", applications: 3, published: "25/01/2026", location: "Algiers" },
  { id: 3, title: "Data Analyst Intern", type: "Internship", status: "Active", applications: 2, published: "25/01/2026", location: "Bejaia" },
  { id: 4, title: "Backend Engineer", type: "Job", status: "Active", applications: 3, published: "25/01/2026", location: "Algiers" },
];

const candidates = [
  { id: 1, name: "Amira Benali", role: "Product Design Intern", match: 96, status: "Under Review" },
  { id: 2, name: "Karim Hadj", role: "Frontend Developer", match: 91, status: "Interview" },
  { id: 3, name: "Sofia Messaoudi", role: "Data Analyst Intern", match: 88, status: "Viewed" },
];

function Logo() {
  return (
    <div className="flex items-center gap-3">
      {/* IC Logo Badge */}
      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#112250] shadow-[0_0_0_1px_#e0c68f30,0_4px_20px_rgba(0,0,0,0.3)]">
        <span className="display text-3xl font-bold tracking-[-1px] text-[#e0c68f]">IC</span>
      </div>

      {/* Text */}
      <div className="leading-none">
        <p className="display text-2xl font-bold tracking-wide text-[#f5f0e9]">InternConnect</p>
        <p className="text-[10px] uppercase tracking-[0.34em] text-[#e0c68f]">Career atelier</p>
      </div>
    </div>
  );
}

function Button({ children, variant = "gold", onClick, className = "" }: { children: React.ReactNode; variant?: "gold" | "ghost" | "cream" | "blue"; onClick?: () => void; className?: string }) {
  const styles = {
    gold: "bg-[#e0c68f] text-[#0a1020] hover:bg-[#f5f0e9]",
    ghost: "border border-[#f5f0e9]/18 bg-white/5 text-[#f5f0e9] hover:border-[#e0c68f]/55 hover:bg-white/10",
    cream: "bg-[#f5f0e9] text-[#112250] hover:bg-white",
    blue: "bg-[#3c5070] text-white hover:bg-[#112250]",
  };
  return <button onClick={onClick} className={`inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition ${styles[variant]} ${className}`}>{children}</button>;
}

function Nav({ page, setPage, role, setRole }: { page: Page; setPage: (page: Page) => void; role: Role; setRole: (r: Role) => void }) {
  const [open, setOpen] = useState(false);
  const links = role === "student" 
    ? [{ label: "Home", page: "home" as Page }, { label: "Opportunities", page: "jobs" as Page }, { label: "Dashboard", page: "dashboard" as Page }, { label: "Profile", page: "profile" as Page }]
    : [{ label: "Dashboard", page: "company-dashboard" as Page }, { label: "Profile", page: "company-profile" as Page }, { label: "Offers", page: "create-offer" as Page }];

  return (
    <header className="fixed left-0 right-0 top-0 z-50 px-4 py-4">
      <div className="glass mx-auto flex max-w-7xl items-center justify-between rounded-full px-4 py-3">
        <button onClick={() => setPage(role === "student" ? "home" : "company-dashboard")} className="cursor-pointer"><Logo /></button>

        <nav className="hidden items-center gap-1 md:flex">
          {links.map((link) => (
            <button key={link.page} onClick={() => setPage(link.page)} className={`rounded-full px-4 py-2 text-sm transition ${page === link.page ? "bg-[#f5f0e9] text-[#112250]" : "text-[#f5f0e9]/72 hover:bg-white/8 hover:text-white"}`}>
              {link.label}
            </button>
          ))}

        </nav>

        <div className="hidden items-center gap-3 md:flex">
          {role === "student" ? (
            <>
              <button onClick={() => window.alert("You have 3 new updates.")} className="rounded-full p-3 text-[#f5f0e9]/75 transition hover:bg-white/10"><Bell size={18} /></button>
              <Button onClick={() => setPage("login")} variant="ghost" className="py-2.5">Sign in</Button>
            </>
          ) : (
            <>
              <Button onClick={() => setPage("create-offer")} variant="blue" className="py-2.5">+ Create Offer</Button>
              <div className="flex items-center gap-2 rounded-full bg-white/5 px-3 py-1 text-sm"><Building2 size={16} /> Condor Electronics</div>
            </>
          )}
          <button onClick={() => { setRole(role === "student" ? "company" : "student"); setPage(role === "student" ? "company-dashboard" : "home"); }} className="rounded-full border border-[#e0c68f]/30 px-4 py-2 text-xs text-[#e0c68f] hover:bg-[#e0c68f]/10">
            Switch to {role === "student" ? "Company" : "Student"}
          </button>
        </div>

        <button onClick={() => setOpen(!open)} className="rounded-full p-3 text-white md:hidden">{open ? <X /> : <Menu />}</button>
      </div>
    </header>
  );
}

function Home({ setPage }: { setPage: (page: Page) => void }) {
  return (
    <main className="leaf-bg relative overflow-hidden grain">
      <section className="hero-bg relative min-h-screen px-4 pb-16 pt-28">
        <div className="relative z-10 mx-auto grid min-h-[calc(100vh-7rem)] max-w-7xl items-center gap-10 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="reveal max-w-3xl">
            <p className="mb-5 inline-flex rounded-full border border-[#e0c68f]/35 bg-[#112250]/50 px-4 py-2 text-xs uppercase tracking-[0.34em] text-[#e0c68f]">Premium student hiring</p>
            <h1 className="display text-6xl font-bold leading-[0.92] text-[#f5f0e9] sm:text-7xl lg:text-8xl">Careers with a quieter kind of luxury.</h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-[#f5f0e9]/75">Inspired by editorial layouts, botanical depth, sapphire glass panels, and soft cream surfaces, InternConnect turns internship search into a calm and confident hiring experience.</p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button onClick={() => setPage("jobs")}>Explore opportunities <ArrowUpRight size={17} /></Button>
              <Button onClick={() => setPage("dashboard")} variant="ghost">Open student dashboard</Button>
            </div>
          </div>
          <div className="slide-in relative">
            <div className="floaty rounded-[2.25rem] border border-[#f5f0e9]/18 bg-[#112250]/58 p-5 shadow-2xl shadow-black/35 backdrop-blur-md">
              <div className="cream-panel rounded-[1.75rem] p-6">
                <div className="flex items-center justify-between"><div><p className="text-xs uppercase tracking-[0.28em] text-[#3c5070]">Smart match</p><h2 className="display mt-2 text-5xl font-bold text-[#112250]">96%</h2></div><Sparkles className="text-[#e0c68f]" size={34} /></div>
                <div className="my-6 h-px bg-[#112250]/15" />
                <div className="mt-6 space-y-3">{studentJobs.slice(0, 3).map((job) => <div key={job.id} className="flex items-center justify-between rounded-2xl bg-white/65 p-3"><div><p className="text-sm font-bold text-[#112250]">{job.role}</p><p className="text-xs text-[#3c5070]">{job.company}</p></div><span className="rounded-full bg-[#112250] px-3 py-1 text-xs text-[#f5f0e9]">{job.match}%</span></div>)}</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}

function Jobs() {
  const [query, setQuery] = useState("");
  const [saved, setSaved] = useState(new Set(studentJobs.filter(j => j.saved).map(j => j.id)));
  const [filters, setFilters] = useState(new Set<string>());
  const [notice, setNotice] = useState("Use the filters or search to refine opportunities.");

  const filteredJobs = useMemo(() => studentJobs.filter(job => {
    const searchHit = `${job.role} ${job.company} ${job.location} ${job.type} ${job.skills.join(" ")}`.toLowerCase().includes(query.toLowerCase());
    const filterHit = filters.size === 0 || filters.has(job.type) || filters.has(job.location);
    return searchHit && filterHit;
  }), [query, filters]);

  const toggleSaved = (id: number) => setSaved(prev => { const next = new Set(prev); next.has(id) ? next.delete(id) : next.add(id); return next; });
  const toggleFilter = (value: string) => setFilters(prev => { const next = new Set(prev); next.has(value) ? next.delete(value) : next.add(value); return next; });
  const openDetails = (job: typeof studentJobs[number]) => setNotice(`${job.role} at ${job.company}: ${job.note}`);
  const applyToJob = (job: typeof studentJobs[number]) => setNotice(`Application sent to ${job.company} for ${job.role}. Track it from the dashboard.`);

  return (
    <main className="leaf-bg min-h-screen px-4 pb-20 pt-28">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
          <div><p className="text-xs uppercase tracking-[0.34em] text-[#e0c68f]">Opportunity room</p><h1 className="display mt-3 text-6xl font-bold text-white">Bestsellers for your career.</h1></div>
          <div className="glass flex w-full max-w-xl items-center gap-3 rounded-full px-5 py-3">
            <Search size={18} className="text-[#e0c68f]" />
            <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search role, company, or skill" className="w-full bg-transparent text-sm text-white placeholder:text-white/38" />
          </div>
        </div>
        <p className="mb-5 rounded-2xl border border-[#e0c68f]/25 bg-[#e0c68f]/10 px-4 py-3 text-sm text-[#f5f0e9]/80">{notice}</p>
        <div className="grid gap-5 lg:grid-cols-[280px_1fr]">
          <aside className="glass h-max rounded-[2rem] p-5">
            <h2 className="mb-4 text-sm font-bold text-white">Filters</h2>
            {[["Type", ["Internship", "Part-time", "PFE"]], ["Location", ["Algiers", "Oran", "Constantine", "Remote"]]].map(([title, values]) => (
              <div key={title as string} className="border-t border-white/10 py-5 first:border-t-0 first:pt-0">
                <p className="mb-3 text-xs uppercase tracking-[0.24em] text-[#e0c68f]">{title as string}</p>
                <div className="space-y-2">{(values as string[]).map(v => <label key={v} className="flex cursor-pointer items-center gap-3 text-sm text-white/65"><input type="checkbox" checked={filters.has(v)} onChange={() => toggleFilter(v)} className="h-4 w-4 accent-[#e0c68f]" /> {v}</label>)}</div>
              </div>
            ))}
            <Button onClick={() => setNotice(`${filteredJobs.length} matching opportunities found.`)} className="w-full" variant="gold">Apply filters</Button>
            <Button onClick={() => { setFilters(new Set()); setQuery(""); setNotice("Filters cleared."); }} className="mt-3 w-full" variant="ghost">Clear all</Button>
          </aside>
          <section className="grid gap-5 md:grid-cols-2">
            {filteredJobs.map(job => (
              <article key={job.id} className="soft-card glass rounded-[2rem] p-6">
                <div className="mb-6 flex items-start justify-between">
                  <div className="rounded-2xl bg-[#f5f0e9] px-4 py-3 text-[#112250]"><p className="display text-4xl font-bold leading-none">{job.company.charAt(0)}</p></div>
                  <button onClick={() => toggleSaved(job.id)} className="rounded-full p-2 text-white/70 hover:bg-white/10"><Heart size={20} className={saved.has(job.id) ? "fill-[#e0c68f] text-[#e0c68f]" : ""} /></button>
                </div>
                <h3 className="text-xl font-bold text-white">{job.role}</h3>
                <p className="text-sm text-white/55">{job.company}</p>
                <div className="mt-5 flex flex-wrap gap-2">{job.skills.map(s => <span key={s} className="rounded-full bg-white/8 px-3 py-1 text-xs text-white/70">{s}</span>)}</div>
                <div className="mt-6 grid grid-cols-2 gap-3">
                  <Button onClick={() => openDetails(job)} variant="ghost" className="py-2.5">Details</Button>
                  <Button onClick={() => applyToJob(job)} className="py-2.5">Apply</Button>
                </div>
              </article>
            ))}
          </section>
        </div>
      </div>
    </main>
  );
}

function StudentDashboard() {
  return (
    <main className="leaf-bg min-h-screen px-4 pb-20 pt-32">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="glass rounded-[2.5rem] p-8"><h1 className="display text-6xl font-bold leading-none text-white">Your application ceremony.</h1></div>
          <div className="cream-panel rounded-[2.5rem] p-8"><p className="text-xs text-[#3c5070]">Profile strength</p><div className="mt-5 flex items-end justify-between"><span className="display text-7xl font-bold text-[#112250]">82%</span><Shield className="text-[#e0c68f]" size={34} /></div></div>
        </div>
        <div className="grid gap-5 md:grid-cols-4">
          {[["Applications", "12", FileText], ["Views", "248", Eye], ["Saved", "8", Bookmark], ["Messages", "5", MessageSquare]].map(([label, value, Icon]) => (
            <div key={label as string} className="glass rounded-[2rem] p-6"><Icon className="text-[#e0c68f]" size={22} /><p className="display mt-6 text-5xl font-bold text-white">{value as string}</p><p className="text-sm text-white/55">{label as string}</p></div>
          ))}
        </div>
      </div>
    </main>
  );
}

function StudentProfile() {
  const [notice, setNotice] = useState("Complete your profile and save it for recruiter visibility.");
  const [skills, setSkills] = useState(["React", "UX", "Python", "SQL", "Research", "Figma"]);
  const addSkill = () => {
    const s = window.prompt("Add a new skill");
    if (s) { setSkills([...skills, s]); setNotice(`${s} added.`); }
  };
  return (
    <main className="leaf-bg min-h-screen px-4 pb-20 pt-32">
      <div className="mx-auto grid max-w-7xl gap-5 lg:grid-cols-[0.8fr_1.2fr]">
        <aside className="glass rounded-[2.5rem] p-8">
          <div className="h-28 w-28 rounded-[2rem] bg-[#f5f0e9] p-1"><div className="flex h-full w-full items-center justify-center rounded-[1.7rem] bg-[#112250]"><User size={42} /></div></div>
          <h1 className="display mt-6 text-5xl font-bold text-white">Student profile</h1>
          <Button onClick={() => setNotice("Profile saved successfully.")} className="mt-8 w-full" variant="gold">Save Profile</Button>
          <p className="mt-3 text-xs text-[#e0c68f]">{notice}</p>
        </aside>
        <section className="grid gap-5">
          <div className="cream-panel rounded-[2.5rem] p-8">
            <h2 className="display text-4xl font-bold text-[#112250]">Personal information</h2>
            <div className="mt-6 grid gap-4 md:grid-cols-2">
              {[[User, "Full name"], [Mail, "Email"], [Phone, "Phone"], [Building2, "University"]].map(([Icon, label]) => <label key={label as string} className="relative block"><Icon className="absolute left-4 top-1/2 -translate-y-1/2 text-[#3c5070]" size={17} /><input placeholder={label as string} className="focus-gold w-full rounded-full border border-[#112250]/12 bg-white/75 py-4 pl-12 pr-4 text-sm text-[#112250]" /></label>)}
            </div>
            <textarea placeholder="Short professional bio" className="focus-gold mt-4 min-h-32 w-full rounded-[1.8rem] border border-[#112250]/12 bg-white/75 p-5 text-sm text-[#112250]" />
          </div>
          <div className="glass rounded-[2rem] p-6">
            <div className="flex items-center justify-between"><h3 className="font-bold text-white">Skills</h3><button onClick={addSkill} className="text-xs text-[#e0c68f]">+ Add</button></div>
            <div className="mt-4 flex flex-wrap gap-2">{skills.map(s => <button key={s} onClick={() => setSkills(skills.filter(x => x !== s))} className="rounded-full bg-white/8 px-3 py-1 text-xs">{s} ×</button>)}</div>
          </div>
        </section>
      </div>
    </main>
  );
}

// ================= COMPANY PAGES =================

function CompanyDashboard({ setPage }: { setPage: (p: Page) => void }) {
  return (
    <main className="leaf-bg min-h-screen px-4 pb-20 pt-32">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="display text-5xl font-bold text-white">Bienvenue, Condor Electronics</h1>
            <p className="text-white/60">Voici ce qui se passe avec votre recrutement aujourd'hui</p>
          </div>
        </div>

        <div className="grid gap-5 md:grid-cols-4">
          {[
            { icon: FileText, label: "Offres Actives", value: "11", change: "+12%" },
            { icon: Users, label: "Total Candidats", value: "13", change: "+28%" },
            { icon: Clock, label: "En Attente", value: "0", change: "" },
            { icon: Eye, label: "Vues des Offres", value: "550", change: "+28%" },
          ].map((stat, i) => (
            <div key={i} className="glass rounded-[2rem] p-6">
              <div className="flex items-center gap-4">
                <div className="rounded-xl bg-white/10 p-3"><stat.icon className="text-[#e0c68f]" /></div>
                <div>
                  <p className="text-sm text-white/60">{stat.label}</p>
                  <p className="display text-4xl font-bold text-white">{stat.value}</p>
                </div>
              </div>
              {stat.change && <p className="mt-2 text-xs text-green-400">{stat.change}</p>}
            </div>
          ))}
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1.6fr_0.9fr]">
          <div className="glass rounded-[2rem] p-6">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="display text-3xl font-bold text-white">Recently Published Offers</h2>
              <Button onClick={() => setPage("create-offer")} variant="ghost">Voir tout</Button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-white/10 text-left text-white/50"><th className="py-3">Offer Title</th><th>Type</th><th>Status</th><th>Applications</th><th>Actions</th></tr></thead>
                <tbody>
                  {companyOffers.map(o => (
                    <tr key={o.id} className="border-b border-white/10">
                      <td className="py-4 font-medium text-white">{o.title}</td>
                      <td><span className="rounded-full bg-white/10 px-3 py-1 text-xs">{o.type}</span></td>
                      <td className="text-green-400">● Active</td>
                      <td>{o.applications}</td>
                      <td><Button onClick={() => setPage("candidates")} variant="blue" className="px-4 py-1 text-xs">View Candidates</Button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="glass rounded-[2rem] p-6">
            <h2 className="display text-3xl font-bold text-white mb-5">Quick Actions</h2>
            <div className="space-y-3">
              <Button onClick={() => setPage("create-offer")} className="w-full" variant="gold">Create New Offer</Button>
              <Button onClick={() => setPage("candidates")} className="w-full" variant="ghost">Review Candidates</Button>
              <Button onClick={() => setPage("company-profile")} className="w-full" variant="ghost">Edit Company Profile</Button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

function CompanyProfile() {
  const [notice, setNotice] = useState("Your company profile is visible to students.");
  return (
    <main className="leaf-bg min-h-screen px-4 pb-20 pt-32">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8"><h1 className="display text-5xl font-bold text-white">Profil de l'Entreprise</h1><p className="text-white/60">Gérez les informations publiques de votre entreprise</p></div>

        <div className="glass rounded-[2.5rem] p-8">
          <div className="mb-6"><p className="font-medium text-white">Logo de l'Entreprise</p><button onClick={() => setNotice("Logo uploaded successfully.")} className="mt-3 flex items-center gap-2 rounded-xl border border-[#e0c68f]/30 px-4 py-2 text-sm"><Upload size={16} /> Télécharger le Logo</button></div>

          <div className="space-y-6">
            <div><label className="text-sm text-white/70">Company Name *</label><input defaultValue="Condor Electronics" className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 p-4 text-white" /></div>
            <div><label className="text-sm text-white/70">Company Description *</label><textarea defaultValue="Leading electronics manufacturer in Algeria." className="mt-2 h-28 w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-white" /></div>
            <div><label className="text-sm text-white/70">Field of Activity</label><input defaultValue="Electronics & Manufacturing" className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 p-4 text-white" /></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div><label className="text-sm text-white/70">Address</label><input defaultValue="Zone Industrielle, Bordj Bou Arreridj" className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 p-4 text-white" /></div>
              <div><label className="text-sm text-white/70">Website</label><input defaultValue="https://condor.dz" className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 p-4 text-white" /></div>
              <div><label className="text-sm text-white/70">Contact Email</label><input defaultValue="hr@condor.dz" className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 p-4 text-white" /></div>
            </div>
            <Button onClick={() => setNotice("Company profile saved successfully!")} className="w-full" variant="gold">Enregistrer le Profil</Button>
            <p className="text-center text-sm text-[#e0c68f]">{notice}</p>
          </div>
        </div>
      </div>
    </main>
  );
}

function CreateOffer({ setPage }: { setPage: (p: Page) => void }) {
  const [notice, setNotice] = useState("");
  return (
    <main className="leaf-bg min-h-screen px-4 pb-20 pt-32">
      <div className="mx-auto max-w-3xl">
        <h1 className="display text-5xl font-bold text-white">Créer une nouvelle offre</h1>
        <div className="mt-8 glass rounded-[2.5rem] p-8 space-y-6">
          <div><label className="text-sm text-white/70">Offer Title *</label><input placeholder="Full Stack Developer" className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 p-4 text-white" /></div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="text-sm text-white/70">Type</label><select className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 p-4 text-white"><option>Internship</option><option>Job</option><option>PFE</option></select></div>
            <div><label className="text-sm text-white/70">Location</label><input placeholder="Algiers" className="mt-2 w-full rounded-xl border border-white/10 bg-white/5 p-4 text-white" /></div>
          </div>
          <div><label className="text-sm text-white/70">Description</label><textarea placeholder="Describe the role..." className="mt-2 h-28 w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-white" /></div>
          <div className="flex gap-4">
            <Button onClick={() => { setNotice("Offer published successfully!"); setTimeout(() => setPage("company-dashboard"), 800); }} className="flex-1" variant="gold">Publish Offer</Button>
            <Button onClick={() => setPage("company-dashboard")} variant="ghost" className="flex-1">Cancel</Button>
          </div>
          {notice && <p className="text-center text-[#e0c68f] mt-4">{notice}</p>}
        </div>
      </div>
    </main>
  );
}

function CandidatesView({ setPage }: { setPage: (p: Page) => void }) {
  return (
    <main className="leaf-bg min-h-screen px-4 pb-20 pt-32">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8 flex items-center justify-between"><h1 className="display text-5xl font-bold text-white">Candidates</h1><Button onClick={() => setPage("company-dashboard")} variant="ghost">Back to Dashboard</Button></div>
        <div className="glass rounded-[2.5rem] p-8">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-white/10 text-left text-white/50"><th className="py-4">Candidate</th><th>Role</th><th>Match</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {candidates.map(c => (
                <tr key={c.id} className="border-b border-white/10">
                  <td className="py-5 font-medium text-white">{c.name}</td>
                  <td className="text-white/70">{c.role}</td>
                  <td><span className="rounded-full bg-[#e0c68f]/20 px-3 py-1 text-xs text-[#e0c68f]">{c.match}%</span></td>
                  <td className="text-white/70">{c.status}</td>
                  <td><Button variant="blue" className="px-4 py-1 text-xs">Message</Button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </main>
  );
}

function Login({ setPage, setRole }: { setPage: (p: Page) => void; setRole: (r: Role) => void }) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [roleTab, setRoleTab] = useState<Role>("student");
  const [notice, setNotice] = useState("Use any email and password to enter the demo.");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRole(roleTab);
    setNotice(mode === "login" ? "Signed in successfully." : "Account created.");
    setTimeout(() => setPage(roleTab === "student" ? "dashboard" : "company-dashboard"), 400);
  };

  return (
    <main className="relative min-h-screen overflow-hidden bg-[url('https://images.pexels.com/photos/1624496/pexels-photo-1624496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=950&w=1600')] bg-cover bg-center px-4 py-10">
      <div className="absolute inset-0 bg-[#0a1020]/55" />
      <div className="relative mx-auto flex min-h-[calc(100vh-5rem)] max-w-7xl items-center justify-center">
        <div className="glass w-full max-w-lg rounded-[2.5rem] p-8 sm:p-10">
          <div className="mb-8 flex justify-center"><button onClick={() => setPage("home")}><Logo /></button></div>
          <div className="mb-6 flex rounded-full border border-[#e0c68f]/30 p-1">
            <button onClick={() => setRoleTab("student")} className={`flex-1 rounded-full py-2 text-sm ${roleTab === "student" ? "bg-[#e0c68f] text-[#0a1020]" : "text-white/70"}`}>Student</button>
            <button onClick={() => setRoleTab("company")} className={`flex-1 rounded-full py-2 text-sm ${roleTab === "company" ? "bg-[#e0c68f] text-[#0a1020]" : "text-white/70"}`}>Company</button>
          </div>

          <h1 className="display text-center text-5xl font-bold text-white">{mode === "login" ? "Welcome back" : "Create account"}</h1>
          <p className="mt-2 text-center text-sm text-white/60">{notice}</p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            {mode === "signup" && roleTab === "company" && (
              <>
                <input placeholder="Company Name" className="focus-gold w-full rounded-full border border-white/14 bg-white/12 p-4 text-white placeholder:text-white/48" />
                <input placeholder="Address" className="focus-gold w-full rounded-full border border-white/14 bg-white/12 p-4 text-white placeholder:text-white/48" />
                <input placeholder="Field of Activity" className="focus-gold w-full rounded-full border border-white/14 bg-white/12 p-4 text-white placeholder:text-white/48" />
              </>
            )}
            {mode === "signup" && roleTab === "student" && (
              <input placeholder="Full name" className="focus-gold w-full rounded-full border border-white/14 bg-white/12 p-4 text-white placeholder:text-white/48" />
            )}
            <input placeholder="Email" className="focus-gold w-full rounded-full border border-white/14 bg-white/12 p-4 text-white placeholder:text-white/48" />
            <input type="password" placeholder="Password" className="focus-gold w-full rounded-full border border-white/14 bg-white/12 p-4 text-white placeholder:text-white/48" />
            <Button className="w-full py-4" variant="gold">{mode === "login" ? "Login" : "Sign up"}</Button>
          </form>

          <div className="mt-6 flex justify-between text-sm text-white/60">
            <button onClick={() => setNotice("Password reset link sent.")}>Forgot password?</button>
            <button onClick={() => setMode(mode === "login" ? "signup" : "login")}>{mode === "login" ? "Sign up" : "Sign in"}</button>
          </div>
        </div>
      </div>
    </main>
  );
}

function Footer({ setPage, role }: { setPage: (p: Page) => void; role: Role }) {
  return (
    <footer className="leaf-bg border-t border-white/10 px-4 py-10">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 md:flex-row md:items-center md:justify-between">
        <Logo />
        <div className="flex flex-wrap gap-4 text-sm text-white/55">
          {role === "student" ? ["jobs", "dashboard", "profile"].map(p => <button key={p} onClick={() => setPage(p as Page)} className="hover:text-[#e0c68f]">{p}</button>) :
           ["company-dashboard", "company-profile", "create-offer"].map(p => <button key={p} onClick={() => setPage(p as Page)} className="hover:text-[#e0c68f]">{p}</button>)}
        </div>
        <p className="text-sm text-white/40">InternConnect 2025</p>
      </div>
    </footer>
  );
}



export default function App() {
  const [page, setPage] = useState<Page>("home");
  const [role, setRole] = useState<Role>("student");

  const render = () => {
    if (page === "jobs") return <Jobs />;
    if (page === "dashboard") return <StudentDashboard />;
    if (page === "profile") return <StudentProfile />;
    if (page === "login") return <Login setPage={setPage} setRole={setRole} />;
    if (page === "company-dashboard") return <CompanyDashboard setPage={setPage} />;
    if (page === "company-profile") return <CompanyProfile />;
    if (page === "create-offer") return <CreateOffer setPage={setPage} />;
    if (page === "candidates") return <CandidatesView setPage={setPage} />;
    return <Home setPage={setPage} />;
  };

  return (
    <div className="min-h-screen bg-[#0a1020]">
      {page !== "login" && <Nav page={page} setPage={setPage} role={role} setRole={setRole} />}
      {render()}
      {page !== "login" && <Footer setPage={setPage} role={role} />}
    </div>
  );
}
